# Akuntansi Seru

Website pembelajaran akuntansi interaktif untuk siswa SMK Kelas X Akuntansi dan Keuangan Lembaga.

## Fitur
- Materi akuntansi dasar
- Simulasi transaksi interaktif
- 15 soal latihan
- 3 game edukasi
- Kamus 30 istilah
- Kalkulator biasa
- Progress dan badge dengan localStorage
- Responsive untuk HP dan laptop
- Tanpa backend, database, YouTube, atau API eksternal

## Menjalankan
Buka `index.html` langsung di browser, atau gunakan Live Server.

## GitHub Pages
Upload repository ke GitHub, lalu buka **Settings → Pages → Deploy from branch → main → / (root) → Save**.

## Vercel
Import repository ke Vercel. Karena website ini static, tidak perlu build command.
